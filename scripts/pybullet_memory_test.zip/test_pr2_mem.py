import pybullet as p
import pybullet_data
import os
import psutil
from pympler import tracker
import sys

# from https://github.com/caelan/ss-pybullet/blob/master/pybullet_tools/utils.py
class HideOutput(object):
    '''
    A context manager that block stdout for its scope, usage:

    with HideOutput():
        os.system('ls -l')
    '''
    def __init__(self, enable=True):
        self.enable = enable
        if not self.enable:
            return
        sys.stdout.flush()
        self._origstdout = sys.stdout
        self._oldstdout_fno = os.dup(sys.stdout.fileno())
        self._devnull = os.open(os.devnull, os.O_WRONLY)

    def __enter__(self):
        if not self.enable:
            return
        self._newstdout = os.dup(1)
        os.dup2(self._devnull, 1)
        os.close(self._devnull)
        sys.stdout = os.fdopen(self._newstdout, 'w')

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not self.enable:
            return
        #sys.stdout.close()
        sys.stdout = self._origstdout
        sys.stdout.flush()
        os.dup2(self._oldstdout_fno, 1)
        os.close(self._oldstdout_fno) # Added

def main():
    tr = tracker.SummaryTracker()

    for i in range(100000):
        client = p.connect(p.DIRECT)
        p.setPhysicsEngineParameter(enableFileCaching=1)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        plane = p.loadURDF("plane.urdf", physicsClientId=client)
        #atlas = p.loadURDF("atlas/atlas_v4_with_multisense.urdf", [-2,3,-0.5], physicsClientId=client)
        pr2_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pr2.urdf')
        # print pr2_path
        with HideOutput():
            pr2 = p.loadURDF(pr2_path, useFixedBase=True, globalScaling=1, physicsClientId=client)
        p.removeBody(pr2)
        #p.removeBody(atlas)
        p.resetSimulation(client)

        if i % 100 == 0:
            print('-----------------------------------')
            tr.print_diff()
            process = psutil.Process(os.getpid())
            print(process.get_memory_info())

        p.disconnect(client)

if __name__ == '__main__':
    main()
