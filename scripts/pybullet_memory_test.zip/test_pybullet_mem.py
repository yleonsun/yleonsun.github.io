import pybullet as p
import numpy as np
import pybullet_data
import os
import psutil
from pympler import tracker


def create_box(wlh, client):
    collision_id = p.createCollisionShape(p.GEOM_BOX, halfExtents=wlh, physicsClientId=client)
    visual_id = p.createVisualShape(p.GEOM_BOX, halfExtents=wlh, physicsClientId=client)
    box = p.createMultiBody(baseMass=1, baseCollisionShapeIndex=collision_id,
                            baseVisualShapeIndex=visual_id, physicsClientId=client)
    return box


def main():
    tr = tracker.SummaryTracker()
    client = p.connect(p.DIRECT)
    for i in range(100000):

        p.setPhysicsEngineParameter(enableFileCaching=1)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        plane = p.loadURDF("plane.urdf")
        wlh = np.random.uniform([0.1, 0.1, 0.1], [1., 1., 1.])
        box = create_box(wlh, client)
        p.removeBody(plane)
        p.removeBody(box)
        #p.resetSimulation(client)

        if i % 100 == 0:
            print('-----------------------------------')
            tr.print_diff()
            process = psutil.Process(os.getpid())
            print(process.get_memory_info())

    p.disconnect(client)

if __name__ == '__main__':
    main()
